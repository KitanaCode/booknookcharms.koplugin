# Book Nook Charms v1.0.0

A cozy KOReader plugin for decorating your reading screen with ribbon bookmarks, dog-ear corner charms, night charms, and black-and-white e-ink charms.

## Highlights

- Ribbon and dog-ear bookmark charms
- Night-friendly charm options
- Black-and-white e-ink charm set
- Charm Library and Charm Types menus
- Favorite Charms
- Charm Studio for size and placement
- Day/Night Pair mode
- Reader gesture actions
- Custom charm folder and starter templates
- Clean install folder: `booknookcharms.koplugin`

## Install

1. Download `Book Nook Charms V1.0.0.zip`.
2. Unzip it.
3. Copy `booknookcharms.koplugin` into:

```text
koreader/plugins/
```

4. Restart KOReader.
